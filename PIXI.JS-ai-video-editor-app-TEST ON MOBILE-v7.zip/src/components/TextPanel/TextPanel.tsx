
import React, { useState } from 'react';
import { useEditorStore } from '../../stores/editorStore';
import './TextPanel.css';

interface TextPanelProps {
  editor: ReturnType<typeof useEditorStore>;
}

const fontFamilies = [
  'Inter',
  'Arial',
  'Georgia',
  'Courier New',
  'Impact',
  'Comic Sans MS',
];

const animations = [
  { id: 'none', name: 'None' },
  { id: 'fadeIn', name: 'Fade In' },
  { id: 'slideUp', name: 'Slide Up' },
  { id: 'typewriter', name: 'Typewriter' },
  { id: 'bounce', name: 'Bounce' },
];

const presetStyles = [
  { name: 'Title', fontSize: 48, fontWeight: 'bold', color: '#ffffff' },
  { name: 'Subtitle', fontSize: 32, fontWeight: '500', color: '#ffffff' },
  { name: 'Caption', fontSize: 20, fontWeight: '400', color: '#ffffff' },
  { name: 'Lower Third', fontSize: 24, fontWeight: '500', color: '#ffffff', backgroundColor: 'rgba(0,0,0,0.5)' },
];

const TextPanel: React.FC<TextPanelProps> = ({ editor }) => {
  const [textContent, setTextContent] = useState('Your text here');
  const [fontSize, setFontSize] = useState(32);
  const [fontFamily, setFontFamily] = useState('Inter');
  const [fontColor, setFontColor] = useState('#ffffff');
  const [fontWeight, setFontWeight] = useState('500');
  const [animation, setAnimation] = useState<'none' | 'fadeIn' | 'slideUp' | 'typewriter' | 'bounce'>('none');
  const [duration, setDuration] = useState(5);

  const handleAddText = () => {
    const textTrack = editor.state.project.tracks.find(t => t.type === 'text');
    
    editor.addTextOverlay({
      text: textContent,
      x: 50,
      y: 50,
      fontSize,
      fontFamily,
      color: fontColor,
      fontWeight,
      startTime: editor.state.currentTime,
      endTime: editor.state.currentTime + duration,
      trackId: textTrack?.id || '',
      animation,
      textAlign: 'center',
    });
  };

  const handlePresetStyle = (preset: typeof presetStyles[0]) => {
    setFontSize(preset.fontSize);
    setFontWeight(preset.fontWeight);
    setFontColor(preset.color);
  };

  const handleUpdateSelectedText = () => {
    if (!editor.state.selectedTextId) return;
    
    editor.updateTextOverlay(editor.state.selectedTextId, {
      text: textContent,
      fontSize,
      fontFamily,
      color: fontColor,
      fontWeight,
      animation,
    });
  };

  return (
    <div className="text-panel">
      <div className="panel-header">
        <h3>Text</h3>
      </div>

      <div className="text-content">
        <div className="preset-styles">
          <label>Preset Styles</label>
          <div className="preset-grid">
            {presetStyles.map((preset, index) => (
              <button
                key={index}
                className="preset-btn"
                onClick={() => handlePresetStyle(preset)}
              >
                {preset.name}
              </button>
            ))}
          </div>
        </div>

        <div className="form-group">
          <label>Text Content</label>
          <textarea
            value={textContent}
            onChange={(e) => setTextContent(e.target.value)}
            placeholder="Enter your text..."
            rows={3}
          />
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>Font Size</label>
            <input
              type="number"
              value={fontSize}
              onChange={(e) => setFontSize(Number(e.target.value))}
              min={8}
              max={200}
            />
          </div>
          <div className="form-group">
            <label>Duration (s)</label>
            <input
              type="number"
              value={duration}
              onChange={(e) => setDuration(Number(e.target.value))}
              min={0.5}
              max={60}
              step={0.5}
            />
          </div>
        </div>

        <div className="form-group">
          <label>Font Family</label>
          <select value={fontFamily} onChange={(e) => setFontFamily(e.target.value)}>
            {fontFamilies.map(font => (
              <option key={font} value={font}>{font}</option>
            ))}
          </select>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>Font Weight</label>
            <select value={fontWeight} onChange={(e) => setFontWeight(e.target.value)}>
              <option value="300">Light</option>
              <option value="400">Regular</option>
              <option value="500">Medium</option>
              <option value="600">Semi Bold</option>
              <option value="700">Bold</option>
            </select>
          </div>
          <div className="form-group">
            <label>Color</label>
            <div className="color-input-wrapper">
              <input
                type="color"
                value={fontColor}
                onChange={(e) => setFontColor(e.target.value)}
              />
              <span>{fontColor}</span>
            </div>
          </div>
        </div>

        <div className="form-group">
          <label>Animation</label>
          <select 
            value={animation} 
            onChange={(e) => setAnimation(e.target.value as any)}
          >
            {animations.map(anim => (
              <option key={anim.id} value={anim.id}>{anim.name}</option>
            ))}
          </select>
        </div>

        <div className="form-actions">
          <button className="btn-add-text" onClick={handleAddText}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="12" y1="5" x2="12" y2="19" />
              <line x1="5" y1="12" x2="19" y2="12" />
            </svg>
            Add Text
          </button>
          {editor.state.selectedTextId && (
            <button className="btn-update-text" onClick={handleUpdateSelectedText}>
              Update Selected
            </button>
          )}
        </div>

        {editor.state.project.textOverlays.length > 0 && (
          <div className="text-overlays-list">
            <label>Text Overlays</label>
            {editor.state.project.textOverlays.map(overlay => (
              <div 
                key={overlay.id}
                className={`overlay-item ${editor.state.selectedTextId === overlay.id ? 'selected' : ''}`}
                onClick={() => editor.selectText(overlay.id)}
              >
                <span className="overlay-preview" style={{ 
                  fontFamily: overlay.fontFamily,
                  fontSize: 14,
                  fontWeight: overlay.fontWeight as any,
                  color: overlay.color,
                }}>
                  {overlay.text.substring(0, 20)}{overlay.text.length > 20 ? '...' : ''}
                </span>
                <button 
                  className="overlay-delete"
                  onClick={(e) => {
                    e.stopPropagation();
                    editor.deleteTextOverlay(overlay.id);
                  }}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <line x1="18" y1="6" x2="6" y2="18" />
                    <line x1="6" y1="6" x2="18" y2="18" />
                  </svg>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default TextPanel;
