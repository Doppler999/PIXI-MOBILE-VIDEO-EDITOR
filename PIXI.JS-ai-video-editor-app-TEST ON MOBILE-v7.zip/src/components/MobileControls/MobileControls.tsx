
import React from 'react';
import { useEditorStore } from '../../stores/editorStore';
import './MobileControls.css';

interface MobileControlsProps {
  editor: ReturnType<typeof useEditorStore>;
}

const MobileControls: React.FC<MobileControlsProps> = ({ editor }) => {
  return (
    <div className="mobile-controls">
      <div className="mobile-tabs">
        <button 
          className={`mobile-tab ${editor.state.showMedia ? 'active' : ''}`}
          onClick={() => editor.togglePanel('media')}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
            <circle cx="8.5" cy="8.5" r="1.5" />
            <polyline points="21 15 16 10 5 21" />
          </svg>
          <span>Media</span>
        </button>
        <button 
          className={`mobile-tab ${editor.state.showEffects ? 'active' : ''}`}
          onClick={() => editor.togglePanel('effects')}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
          </svg>
          <span>Effects</span>
        </button>
        <button 
          className={`mobile-tab ${editor.state.showText ? 'active' : ''}`}
          onClick={() => editor.togglePanel('text')}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="4 7 4 4 20 4 20 7" />
            <line x1="9" y1="20" x2="15" y2="20" />
            <line x1="12" y1="4" x2="12" y2="20" />
          </svg>
          <span>Text</span>
        </button>
      </div>
    </div>
  );
};

export default MobileControls;
