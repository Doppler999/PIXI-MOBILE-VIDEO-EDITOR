
import React, { useState } from 'react';
import { useEditorStore } from '../../stores/editorStore';
import './Header.css';

interface HeaderProps {
  editor: ReturnType<typeof useEditorStore>;
}

const Header: React.FC<HeaderProps> = ({ editor }) => {
  const [projectName, setProjectName] = useState(editor.state.project.name);
  const [isEditing, setIsEditing] = useState(false);

  const handleExport = () => {
    editor.toggleExportPanel(true);
  };

  const handleUndo = () => {
    console.log('Undo');
  };

  const handleRedo = () => {
    console.log('Redo');
  };

  return (
    <header className="header">
      <div className="header-left">
        <div className="logo">
          <svg viewBox="0 0 32 32" width="32" height="32">
            <defs>
              <linearGradient id="logo-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#6366f1" />
                <stop offset="100%" stopColor="#8b5cf6" />
              </linearGradient>
            </defs>
            <rect x="2" y="2" width="28" height="28" rx="6" fill="url(#logo-gradient)" />
            <path d="M10 8 L10 24 L24 16 Z" fill="white" />
          </svg>
          <span className="logo-text">PixelCut AI</span>
        </div>
      </div>

      <div className="header-center">
        {isEditing ? (
          <input
            type="text"
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            onBlur={() => setIsEditing(false)}
            onKeyDown={(e) => e.key === 'Enter' && setIsEditing(false)}
            className="project-name-input"
            autoFocus
          />
        ) : (
          <h1 
            className="project-name" 
            onClick={() => setIsEditing(true)}
            title="Click to rename"
          >
            {projectName}
          </h1>
        )}
      </div>

      <div className="header-right">
        <div className="header-actions">
          <button className="header-btn" onClick={handleUndo} title="Undo (Ctrl+Z)">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M3 7v6h6" />
              <path d="M21 17a9 9 0 00-9-9 9 9 0 00-6 2.3L3 13" />
            </svg>
          </button>
          <button className="header-btn" onClick={handleRedo} title="Redo (Ctrl+Y)">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 7v6h-6" />
              <path d="M3 17a9 9 0 019-9 9 9 0 016 2.3L21 13" />
            </svg>
          </button>
        </div>
        <div className="header-divider" />
        <button className="btn-export" onClick={handleExport}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
            <polyline points="17 8 12 3 7 8" />
            <line x1="12" y1="3" x2="12" y2="15" />
          </svg>
          Export
        </button>
      </div>
    </header>
  );
};

export default Header;
