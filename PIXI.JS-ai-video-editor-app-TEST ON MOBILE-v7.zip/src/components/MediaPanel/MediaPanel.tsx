
import React, { useRef, useState } from 'react';
import { useEditorStore } from '../../stores/editorStore';
import { MediaItem } from '../../types/editor';
import './MediaPanel.css';

interface MediaPanelProps {
  editor: ReturnType<typeof useEditorStore>;
}

const MediaPanel: React.FC<MediaPanelProps> = ({ editor }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const generateVideoThumbnail = (videoUrl: string, time: number = 1): Promise<string> => {
    return new Promise((resolve) => {
      const video = document.createElement('video');
      video.src = videoUrl;
      video.currentTime = time;
      video.crossOrigin = 'anonymous';
      
      video.onloadeddata = () => {
        const canvas = document.createElement('canvas');
        canvas.width = 160;
        canvas.height = 90;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL('image/jpeg', 0.7));
        } else {
          resolve('');
        }
      };
      
      video.onerror = () => resolve('');
      
      // Fallback timeout
      setTimeout(() => resolve(''), 5000);
    });
  };

  const handleFileSelect = async (files: FileList | null) => {
    if (!files) return;

    for (const file of Array.from(files)) {
      const type = file.type.startsWith('video') ? 'video' : 
                   file.type.startsWith('audio') ? 'audio' : 
                   file.type.startsWith('image') ? 'image' : null;
      
      if (!type) continue;

      const url = URL.createObjectURL(file);
      let duration = 5;
      let thumbnail: string | undefined;
      
      if (type === 'video') {
        const video = document.createElement('video');
        video.src = url;
        video.muted = true;
        
        await new Promise<void>((resolve) => {
          video.onloadedmetadata = async () => {
            duration = video.duration;
            // Generate thumbnail
            const thumb = await generateVideoThumbnail(url, Math.min(1, duration / 2));
            thumbnail = thumb;
            resolve();
          };
          video.onerror = () => resolve();
          video.load();
        });
      } else if (type === 'audio') {
        const audio = document.createElement('audio');
        audio.src = url;
        
        await new Promise<void>((resolve) => {
          audio.onloadedmetadata = () => {
            duration = audio.duration;
            resolve();
          };
          audio.onerror = () => resolve();
        });
      } else if (type === 'image') {
        thumbnail = url;
      }

      const mediaItem: MediaItem = {
        id: Math.random().toString(36).substr(2, 9),
        name: file.name,
        type: type as 'video' | 'audio' | 'image',
        duration,
        file,
        url,
        thumbnail,
      };

      editor.addMediaToLibrary(mediaItem);
    }

    // Reset the file input so the same file can be selected again
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileSelect(e.dataTransfer.files);
  };

  const handleAddToTimeline = (media: MediaItem) => {
    const videoTracks = editor.state.project.tracks.filter(t => t.type === 'video');
    const audioTracks = editor.state.project.tracks.filter(t => t.type === 'audio');
    
    let targetTrackId: string;
    if (media.type === 'video' || media.type === 'image') {
      targetTrackId = videoTracks[0]?.id || '';
    } else {
      targetTrackId = audioTracks[0]?.id || '';
    }

    if (!targetTrackId) return;

    // Find end of existing clips in this track
    const track = editor.state.project.tracks.find(t => t.id === targetTrackId);
    const trackEnd = track?.clips.reduce((acc, clip) => 
      Math.max(acc, clip.trackStart + (clip.endTime - clip.startTime)), 0) || 0;

    editor.addClipToTrack(targetTrackId, {
      mediaId: media.id,
      startTime: 0,
      endTime: media.duration,
      trackStart: trackEnd,
      trimStart: 0,
      trimEnd: 0,
      name: media.name,
      type: media.type,
      effects: [],
      opacity: 1,
      volume: 1,
      muted: false,
      thumbnail: media.thumbnail,
    });
  };

  const openFilePicker = (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    // Reset value before opening to ensure clean state
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    fileInputRef.current?.click();
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <div className="media-panel">
      <div className="panel-header">
        <h3>Media Library</h3>
        <button 
          className="panel-action-btn"
          onClick={openFilePicker}
          title="Import media"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
            <polyline points="17 8 12 3 7 8" />
            <line x1="12" y1="3" x2="12" y2="15" />
          </svg>
        </button>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="video/*,audio/*,image/*"
        multiple
        style={{ display: 'none' }}
        onChange={(e) => handleFileSelect(e.target.files)}
      />

      <div 
        className={`media-drop-zone ${isDragging ? 'dragging' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={editor.state.mediaLibrary.length === 0 ? openFilePicker : undefined}
      >
        {editor.state.mediaLibrary.length === 0 ? (
          <div className="drop-content">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
              <polyline points="17 8 12 3 7 8" />
              <line x1="12" y1="3" x2="12" y2="15" />
            </svg>
            <p>Drop media here</p>
            <span>or click to import</span>
            <span className="supported-formats">Supports video, audio, and images</span>
          </div>
        ) : (
          <div className="media-grid" onClick={(e) => e.stopPropagation()}>
            {editor.state.mediaLibrary.map(media => (
              <div 
                key={media.id} 
                className="media-item"
                title={`${media.name}\nDuration: ${formatDuration(media.duration)}\nClick to add to timeline`}
              >
                <div 
                  className={`media-thumbnail ${media.type}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleAddToTimeline(media);
                  }}
                >
                  {media.thumbnail ? (
                    <img src={media.thumbnail} alt={media.name} />
                  ) : (
                    <div className="media-thumbnail-icon">
                      {media.type === 'video' && (
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                          <polygon points="5 3 19 12 5 21 5 3" />
                        </svg>
                      )}
                      {media.type === 'audio' && (
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M9 18V5l12-2v13" />
                          <circle cx="6" cy="18" r="3" />
                          <circle cx="18" cy="16" r="3" />
                        </svg>
                      )}
                      {media.type === 'image' && (
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
                          <circle cx="8.5" cy="8.5" r="1.5" />
                          <polyline points="21 15 16 10 5 21" />
                        </svg>
                      )}
                    </div>
                  )}
                  <span className="media-duration">{formatDuration(media.duration)}</span>
                  <div className="media-add-hint">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <line x1="12" y1="5" x2="12" y2="19" />
                      <line x1="5" y1="12" x2="19" y2="12" />
                    </svg>
                  </div>
                </div>
                <div className="media-info">
                  <span className="media-name">{media.name}</span>
                  <div className="media-meta">
                    <span className="media-type">{media.type}</span>
                    {media.file && (
                      <span className="media-size">{formatFileSize(media.file.size)}</span>
                    )}
                  </div>
                </div>
                <button 
                  className="media-remove"
                  onClick={(e) => {
                    e.stopPropagation();
                    editor.removeMediaFromLibrary(media.id);
                  }}
                  title="Remove from library"
                >
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <line x1="18" y1="6" x2="6" y2="18" />
                    <line x1="6" y1="6" x2="18" y2="18" />
                  </svg>
                </button>
              </div>
            ))}
            
            {/* Add more button */}
            <div 
              className="media-item add-more"
              onClick={openFilePicker}
            >
              <div className="media-thumbnail add">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="12" y1="5" x2="12" y2="19" />
                  <line x1="5" y1="12" x2="19" y2="12" />
                </svg>
              </div>
              <div className="media-info">
                <span className="media-name">Import More</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MediaPanel;
