
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { useEditorStore } from '../../stores/editorStore';
import './Preview.css';

interface PreviewProps {
  editor: ReturnType<typeof useEditorStore>;
}

const Preview: React.FC<PreviewProps> = ({ editor }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourcesRef = useRef<Map<string, { source: AudioBufferSourceNode; gain: GainNode }>>(new Map());
  const lastTimeRef = useRef<number>(-1);

  // Get the active clip at current time
  const getActiveClip = useCallback(() => {
    const currentTime = editor.state.currentTime;
    
    for (const track of editor.state.project.tracks) {
      if (track.muted || !track.visible) continue;
      
      for (const clip of track.clips) {
        const clipStart = clip.trackStart;
        const clipEnd = clip.trackStart + (clip.endTime - clip.startTime);
        
        if (currentTime >= clipStart && currentTime < clipEnd) {
          return { clip, track };
        }
      }
    }
    return null;
  }, [editor.state.currentTime, editor.state.project.tracks]);

  // Get media for clip
  const getMediaForClip = useCallback((clip: { mediaId: string }) => {
    return editor.state.mediaLibrary.find(m => m.id === clip.mediaId);
  }, [editor.state.mediaLibrary]);

  // Update video display
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const activeData = getActiveClip();
    
    if (!activeData) {
      video.src = '';
      video.style.opacity = '0';
      return;
    }

    const { clip } = activeData;
    const media = getMediaForClip(clip);
    
    if (!media || !media.url) {
      video.src = '';
      video.style.opacity = '0';
      return;
    }

    if (media.type === 'video' || media.type === 'image') {
      if (video.src !== media.url) {
        video.src = media.url;
        video.load();
      }
      
      // Calculate the time within the clip
      const clipLocalTime = clip.startTime + (editor.state.currentTime - clip.trackStart);
      
      // Only update if time changed significantly (avoid micro-updates)
      if (Math.abs(video.currentTime - clipLocalTime) > 0.1) {
        video.currentTime = clipLocalTime;
      }
      
      video.style.opacity = String(clip.opacity);
      video.muted = clip.muted || activeData.track.muted;
      video.volume = clip.volume;
      
      if (editor.state.isPlaying) {
        video.play().catch(() => {});
      } else {
        video.pause();
      }
    } else {
      video.src = '';
      video.style.opacity = '0';
    }
  }, [editor.state.currentTime, editor.state.isPlaying, getActiveClip, getMediaForClip]);

  // Handle audio playback
  useEffect(() => {
    if (!editor.state.isPlaying) {
      // Stop all audio sources
      audioSourcesRef.current.forEach(({ source }) => {
        try { source.stop(); } catch {}
      });
      audioSourcesRef.current.clear();
      return;
    }

    const activeData = getActiveClip();
    if (!activeData) return;

    const { clip, track } = activeData;
    const media = getMediaForClip(clip);
    
    if (!media || !media.url || media.type !== 'audio') return;
    if (clip.muted || track.muted) return;

    // Simple audio handling - create audio element for playback
    const audioId = clip.id;
    if (audioSourcesRef.current.has(audioId)) return;

    const audio = new Audio(media.url);
    const clipLocalTime = clip.startTime + (editor.state.currentTime - clip.trackStart);
    audio.currentTime = clipLocalTime;
    audio.volume = clip.volume;
    
    audio.play().catch(() => {});
    
    audioSourcesRef.current.set(audioId, { 
      source: null as any, 
      gain: null as any 
    });

    // Store audio element reference
    const stopAudio = () => {
      audio.pause();
      audioSourcesRef.current.delete(audioId);
    };

    return () => {
      stopAudio();
    };
  }, [editor.state.isPlaying, editor.state.currentTime, getActiveClip, getMediaForClip]);

  // Handle image display
  const [activeImage, setActiveImage] = useState<string | null>(null);
  
  useEffect(() => {
    const activeData = getActiveClip();
    if (!activeData) {
      setActiveImage(null);
      return;
    }

    const { clip } = activeData;
    const media = getMediaForClip(clip);
    
    if (media?.type === 'image' && media.url) {
      setActiveImage(media.url);
    } else {
      setActiveImage(null);
    }
  }, [getActiveClip, getMediaForClip]);

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    const frames = Math.floor((seconds % 1) * 30);
    
    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}:${frames.toString().padStart(2, '0')}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}:${frames.toString().padStart(2, '0')}`;
  };

  const activeData = getActiveClip();
  const activeMedia = activeData ? getMediaForClip(activeData.clip) : null;

  return (
    <div className="preview-container" ref={containerRef}>
      <div className="preview-header">
        <div className="preview-info">
          <span className="resolution">{editor.state.project.width}×{editor.state.project.height}</span>
          <span className="fps">{editor.state.project.fps} fps</span>
        </div>
        <div className="time-display">
          <span className="current-time">{formatTime(editor.state.currentTime)}</span>
          <span className="separator">/</span>
          <span className="total-time">{formatTime(editor.state.project.duration)}</span>
        </div>
      </div>
      
      <div className="preview-canvas-wrapper">
        {activeImage && (
          <img 
            src={activeImage} 
            alt="Preview" 
            className="preview-image"
            style={{ 
              opacity: activeData?.clip.opacity ?? 1,
            }}
          />
        )}
        
        <video 
          ref={videoRef}
          className="preview-video"
          playsInline
          muted={false}
        />
        
        {/* Text overlays */}
        <div className="text-overlays-container">
          {editor.state.project.textOverlays.map(overlay => {
            if (editor.state.currentTime < overlay.startTime || 
                editor.state.currentTime > overlay.endTime) {
              return null;
            }
            
            let style: React.CSSProperties = {
              position: 'absolute',
              left: `${overlay.x}%`,
              top: `${overlay.y}%`,
              transform: 'translate(-50%, -50%)',
              fontFamily: overlay.fontFamily,
              fontSize: `${overlay.fontSize}px`,
              fontWeight: overlay.fontWeight,
              color: overlay.color,
              textAlign: overlay.textAlign,
              backgroundColor: overlay.backgroundColor,
              padding: overlay.backgroundColor ? '4px 8px' : undefined,
              borderRadius: overlay.backgroundColor ? '4px' : undefined,
              whiteSpace: 'pre-wrap',
              textShadow: '1px 1px 2px rgba(0,0,0,0.5)',
            };
            
            // Animation effects
            if (overlay.animation === 'fadeIn') {
              const progress = Math.min(1, (editor.state.currentTime - overlay.startTime) / 0.5);
              style.opacity = progress;
            } else if (overlay.animation === 'slideUp') {
              const progress = Math.min(1, (editor.state.currentTime - overlay.startTime) / 0.5);
              style.transform = `translate(-50%, calc(-50% + ${(1 - progress) * 30}px))`;
            } else if (overlay.animation === 'bounce') {
              const elapsed = editor.state.currentTime - overlay.startTime;
              const bounce = Math.abs(Math.sin(elapsed * 8)) * 5;
              style.transform = `translate(-50%, calc(-50% - ${bounce}px))`;
            }
            
            return (
              <div key={overlay.id} style={style}>
                {overlay.text}
              </div>
            );
          })}
        </div>
        
        {/* Empty state */}
        {!activeMedia && editor.state.project.tracks.every(t => t.clips.length === 0) && (
          <div className="empty-state">
            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <rect x="3" y="3" width="18" height="18" rx="2" />
              <path d="M12 8v8M8 12h8" />
            </svg>
            <p>Add media to start editing</p>
            <span>Import videos, images, or audio from the panel on the left</span>
          </div>
        )}
        
        {/* No clip at current time */}
        {!activeMedia && editor.state.project.tracks.some(t => t.clips.length > 0) && (
          <div className="no-clip-state">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
            <p>No media at current time</p>
            <span>Move playhead to a clip position</span>
          </div>
        )}
      </div>
      
      <div className="preview-controls">
        <button 
          className="skip-btn"
          onClick={() => editor.setCurrentTime(0)}
          title="Go to start"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M19 20L9 12l10-8v16z" />
            <line x1="5" y1="4" x2="5" y2="20" />
          </svg>
        </button>
        <button 
          className="skip-btn"
          onClick={() => editor.setCurrentTime(Math.max(0, editor.state.currentTime - 5))}
          title="Back 5 seconds"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M11 19l-9-7 9-7v14z" />
          </svg>
        </button>
        <button 
          className={`play-btn ${editor.state.isPlaying ? 'playing' : ''}`}
          onClick={() => editor.setIsPlaying(!editor.state.isPlaying)}
        >
          {editor.state.isPlaying ? (
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <rect x="6" y="4" width="4" height="16" rx="1" />
              <rect x="14" y="4" width="4" height="16" rx="1" />
            </svg>
          ) : (
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M8 5.14v14l11-7-11-7z" />
            </svg>
          )}
        </button>
        <button 
          className="skip-btn"
          onClick={() => editor.setCurrentTime(Math.min(editor.state.project.duration, editor.state.currentTime + 5))}
          title="Forward 5 seconds"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M13 5l9 7-9 7V5z" />
          </svg>
        </button>
        <button 
          className="skip-btn"
          onClick={() => editor.setCurrentTime(editor.state.project.duration)}
          title="Go to end"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M5 4l10 8-10 8V4z" />
            <line x1="19" y1="4" x2="19" y2="20" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default Preview;
