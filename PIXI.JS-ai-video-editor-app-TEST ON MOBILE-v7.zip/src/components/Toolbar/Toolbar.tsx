
import React from 'react';
import { useEditorStore } from '../../stores/editorStore';
import './Toolbar.css';

interface ToolbarProps {
  editor: ReturnType<typeof useEditorStore>;
}

const Toolbar: React.FC<ToolbarProps> = ({ editor }) => {
  const tools = [
    { 
      id: 'media', 
      name: 'Media', 
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
          <circle cx="8.5" cy="8.5" r="1.5" />
          <polyline points="21 15 16 10 5 21" />
        </svg>
      ),
      active: editor.state.showMedia,
      action: () => editor.togglePanel('media'),
    },
    { 
      id: 'effects', 
      name: 'Effects', 
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
        </svg>
      ),
      active: editor.state.showEffects,
      action: () => editor.togglePanel('effects'),
    },
    { 
      id: 'text', 
      name: 'Text', 
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <polyline points="4 7 4 4 20 4 20 7" />
          <line x1="9" y1="20" x2="15" y2="20" />
          <line x1="12" y1="4" x2="12" y2="20" />
        </svg>
      ),
      active: editor.state.showText,
      action: () => editor.togglePanel('text'),
    },
  ];

  const editTools = [
    {
      id: 'split',
      name: 'Split',
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <line x1="12" y1="2" x2="12" y2="22" />
          <path d="M8 6L12 2L16 6" />
          <path d="M8 18L12 22L16 18" />
        </svg>
      ),
      action: () => {
        if (editor.state.selectedClipId) {
          editor.splitClip(editor.state.selectedClipId, editor.state.currentTime);
        }
      },
    },
    {
      id: 'delete',
      name: 'Delete',
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <polyline points="3 6 5 6 21 6" />
          <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" />
        </svg>
      ),
      action: () => {
        if (editor.state.selectedClipId) {
          editor.deleteClip(editor.state.selectedClipId);
        }
      },
    },
  ];

  return (
    <div className="toolbar">
      <div className="toolbar-section">
        {tools.map(tool => (
          <button
            key={tool.id}
            className={`toolbar-btn ${tool.active ? 'active' : ''}`}
            onClick={tool.action}
            title={tool.name}
          >
            {tool.icon}
            <span className="toolbar-btn-label">{tool.name}</span>
          </button>
        ))}
      </div>

      <div className="toolbar-divider" />

      <div className="toolbar-section">
        {editTools.map(tool => (
          <button
            key={tool.id}
            className="toolbar-btn"
            onClick={tool.action}
            title={tool.name}
            disabled={!editor.state.selectedClipId}
          >
            {tool.icon}
            <span className="toolbar-btn-label">{tool.name}</span>
          </button>
        ))}
      </div>

      <div className="toolbar-divider" />

      <div className="toolbar-section">
        <button
          className="toolbar-btn"
          onClick={() => editor.addTrack('video')}
          title="Add Video Track"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="12" y1="5" x2="12" y2="19" />
            <line x1="5" y1="12" x2="19" y2="12" />
          </svg>
          <span className="toolbar-btn-label">Track</span>
        </button>
      </div>
    </div>
  );
};

export default Toolbar;
