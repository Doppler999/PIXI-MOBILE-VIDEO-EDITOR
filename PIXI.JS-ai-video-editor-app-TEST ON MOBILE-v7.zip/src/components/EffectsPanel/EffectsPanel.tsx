
import React, { useState } from 'react';
import { useEditorStore } from '../../stores/editorStore';
import './EffectsPanel.css';

interface EffectsPanelProps {
  editor: ReturnType<typeof useEditorStore>;
}

const filters = [
  { id: 'grayscale', name: 'Grayscale', icon: '◐' },
  { id: 'sepia', name: 'Sepia', icon: '◙' },
  { id: 'invert', name: 'Invert', icon: '◑' },
  { id: 'blur', name: 'Blur', icon: '○' },
  { id: 'brightness', name: 'Brightness', icon: '☀' },
  { id: 'contrast', name: 'Contrast', icon: '◒' },
  { id: 'saturate', name: 'Saturate', icon: '◉' },
  { id: 'hue-rotate', name: 'Hue Rotate', icon: '↻' },
];

const transitions = [
  { id: 'fade', name: 'Fade', icon: '▬' },
  { id: 'slide', name: 'Slide', icon: '→' },
  { id: 'zoom', name: 'Zoom', icon: '⊕' },
  { id: 'wipe', name: 'Wipe', icon: '▬' },
];

const EffectsPanel: React.FC<EffectsPanelProps> = ({ editor }) => {
  const [activeTab, setActiveTab] = useState<'filters' | 'transitions'>('filters');

  const handleApplyEffect = (effectId: string, type: 'filter' | 'transition') => {
    if (!editor.state.selectedClipId) {
      alert('Please select a clip first');
      return;
    }

    const newEffect = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      name: effectId,
      params: {},
    };

    const clip = editor.state.project.tracks
      .flatMap(t => t.clips)
      .find(c => c.id === editor.state.selectedClipId);

    if (clip) {
      editor.updateClip(clip.id, {
        effects: [...clip.effects, newEffect],
      });
    }
  };

  return (
    <div className="effects-panel">
      <div className="panel-header">
        <h3>Effects</h3>
      </div>

      <div className="panel-tabs">
        <button 
          className={`panel-tab ${activeTab === 'filters' ? 'active' : ''}`}
          onClick={() => setActiveTab('filters')}
        >
          Filters
        </button>
        <button 
          className={`panel-tab ${activeTab === 'transitions' ? 'active' : ''}`}
          onClick={() => setActiveTab('transitions')}
        >
          Transitions
        </button>
      </div>

      <div className="effects-content">
        {activeTab === 'filters' && (
          <div className="effects-grid">
            {filters.map(filter => (
              <button
                key={filter.id}
                className="effect-item"
                onClick={() => handleApplyEffect(filter.id, 'filter')}
              >
                <span className="effect-icon">{filter.icon}</span>
                <span className="effect-name">{filter.name}</span>
              </button>
            ))}
          </div>
        )}

        {activeTab === 'transitions' && (
          <div className="effects-grid">
            {transitions.map(transition => (
              <button
                key={transition.id}
                className="effect-item"
                onClick={() => handleApplyEffect(transition.id, 'transition')}
              >
                <span className="effect-icon">{transition.icon}</span>
                <span className="effect-name">{transition.name}</span>
              </button>
            ))}
          </div>
        )}

        {editor.state.selectedClipId && (
          <div className="applied-effects">
            <h4>Applied Effects</h4>
            {(() => {
              const clip = editor.state.project.tracks
                .flatMap(t => t.clips)
                .find(c => c.id === editor.state.selectedClipId);
              
              if (!clip || clip.effects.length === 0) {
                return <p className="no-effects">No effects applied</p>;
              }

              return (
                <div className="effects-list">
                  {clip.effects.map(effect => (
                    <div key={effect.id} className="applied-effect">
                      <span>{effect.name}</span>
                      <button 
                        className="remove-effect"
                        onClick={() => {
                          editor.updateClip(clip.id, {
                            effects: clip.effects.filter(e => e.id !== effect.id),
                          });
                        }}
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              );
            })()}
          </div>
        )}
      </div>
    </div>
  );
};

export default EffectsPanel;
