
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useEditorStore } from '../../stores/editorStore';
import { ExportSettings, RESOLUTION_PRESETS, QUALITY_BITRATES } from '../../types/editor';
import './ExportPanel.css';

interface ExportPanelProps {
  editor: ReturnType<typeof useEditorStore>;
}

interface PreloadedMedia {
  mediaId: string;
  type: 'video' | 'image';
  element: HTMLVideoElement | HTMLImageElement;
  duration: number;
  ready: boolean;
}

const ExportPanel: React.FC<ExportPanelProps> = ({ editor }) => {
  const [settings, setSettings] = useState<ExportSettings>({
    resolution: '1080p',
    fps: 30,
    format: 'webm',
    quality: 'high',
  });
  
  const [exportPhase, setExportPhase] = useState<'settings' | 'preparing' | 'rendering' | 'complete' | 'error'>('settings');
  const [renderedFrames, setRenderedFrames] = useState(0);
  const [totalFrames, setTotalFrames] = useState(0);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [downloadFilename, setDownloadFilename] = useState<string>('');
  const [fileSize, setFileSize] = useState<number>(0);
  const [currentRenderTime, setCurrentRenderTime] = useState<string>('');
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const abortRef = useRef<boolean>(false);
  const preloadedMediaRef = useRef<Map<string, PreloadedMedia>>(new Map());
  const downloadLinkRef = useRef<HTMLAnchorElement | null>(null);

  const handleSettingChange = <K extends keyof ExportSettings>(
    key: K, 
    value: ExportSettings[K]
  ) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const estimateFileSize = useCallback(() => {
    const bitrate = QUALITY_BITRATES[settings.quality];
    const duration = editor.state.project.duration;
    const resolution = RESOLUTION_PRESETS[settings.resolution];
    
    const sizeBytes = (bitrate * duration) / 8;
    const resolutionMultiplier = (resolution.width * resolution.height) / (1920 * 1080);
    const adjustedSize = sizeBytes * resolutionMultiplier;
    
    if (adjustedSize < 1024 * 1024) {
      return `${(adjustedSize / 1024).toFixed(1)} KB`;
    } else if (adjustedSize < 1024 * 1024 * 1024) {
      return `${(adjustedSize / (1024 * 1024)).toFixed(1)} MB`;
    } else {
      return `${(adjustedSize / (1024 * 1024 * 1024)).toFixed(2)} GB`;
    }
  }, [settings, editor.state.project.duration]);

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 100);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`;
  };

  // Preload all media assets with proper async handling
  const preloadMedia = async (): Promise<boolean> => {
    const mediaItems = editor.state.mediaLibrary;
    const allClips = editor.state.project.tracks.flatMap(t => t.clips);
    const uniqueMediaIds = [...new Set(allClips.map(c => c.mediaId))];
    
    console.log('[Export] Preloading media:', uniqueMediaIds.length, 'items');
    
    for (const mediaId of uniqueMediaIds) {
      if (abortRef.current) return false;
      
      const media = mediaItems.find(m => m.id === mediaId);
      if (!media || !media.url) {
        console.warn('[Export] Media not found:', mediaId);
        continue;
      }
      
      // Skip if already preloaded
      if (preloadedMediaRef.current.has(media.id)) continue;
      
      if (media.type === 'image') {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        
        await new Promise<void>((resolve) => {
          const timeout = setTimeout(() => {
            console.warn('[Export] Image load timeout:', media.name);
            resolve();
          }, 5000);
          
          img.onload = () => {
            clearTimeout(timeout);
            preloadedMediaRef.current.set(media.id, {
              mediaId: media.id,
              type: 'image',
              element: img,
              duration: media.duration,
              ready: true,
            });
            console.log('[Export] Image loaded:', media.name);
            resolve();
          };
          
          img.onerror = () => {
            clearTimeout(timeout);
            console.warn('[Export] Image load failed:', media.name);
            resolve();
          };
          
          img.src = media.url;
        });
      } else if (media.type === 'video') {
        const video = document.createElement('video');
        video.crossOrigin = 'anonymous';
        video.muted = true;
        video.preload = 'auto';
        video.playsInline = true;
        
        await new Promise<void>((resolve) => {
          const timeout = setTimeout(() => {
            console.warn('[Export] Video load timeout:', media.name);
            resolve();
          }, 15000);
          
          const onLoaded = () => {
            clearTimeout(timeout);
            preloadedMediaRef.current.set(media.id, {
              mediaId: media.id,
              type: 'video',
              element: video,
              duration: video.duration || media.duration,
              ready: true,
            });
            console.log('[Export] Video loaded:', media.name, 'duration:', video.duration);
            resolve();
          };
          
          const onError = (e: Event) => {
            clearTimeout(timeout);
            console.warn('[Export] Video load failed:', media.name, e);
            resolve();
          };
          
          video.addEventListener('loadedmetadata', onLoaded, { once: true });
          video.addEventListener('canplaythrough', () => {
            // Video is ready to play
          }, { once: true });
          video.addEventListener('error', onError, { once: true });
          
          video.src = media.url;
          video.load();
        });
      }
    }
    
    console.log('[Export] Preloading complete. Loaded:', preloadedMediaRef.current.size, 'items');
    return true;
  };

  const drawMediaToCanvas = (
    ctx: CanvasRenderingContext2D,
    source: HTMLImageElement | HTMLVideoElement,
    canvasWidth: number,
    canvasHeight: number,
    opacity: number = 1
  ) => {
    const isVideo = 'videoWidth' in source;
    const sourceWidth = isVideo ? (source as HTMLVideoElement).videoWidth : (source as HTMLImageElement).naturalWidth;
    const sourceHeight = isVideo ? (source as HTMLVideoElement).videoHeight : (source as HTMLImageElement).naturalHeight;
    
    if (!sourceWidth || !sourceHeight) {
      console.warn('[Export] Invalid source dimensions:', sourceWidth, 'x', sourceHeight);
      return false;
    }
    
    const canvasAspect = canvasWidth / canvasHeight;
    const sourceAspect = sourceWidth / sourceHeight;
    
    let drawWidth, drawHeight, drawX, drawY;
    
    if (sourceAspect > canvasAspect) {
      drawWidth = canvasWidth;
      drawHeight = canvasWidth / sourceAspect;
      drawX = 0;
      drawY = (canvasHeight - drawHeight) / 2;
    } else {
      drawHeight = canvasHeight;
      drawWidth = canvasHeight * sourceAspect;
      drawX = (canvasWidth - drawWidth) / 2;
      drawY = 0;
    }
    
    ctx.globalAlpha = opacity;
    ctx.drawImage(source, drawX, drawY, drawWidth, drawHeight);
    ctx.globalAlpha = 1;
    return true;
  };

  // Seek video to specific time and wait for frame to be ready
  const seekVideo = (video: HTMLVideoElement, time: number): Promise<boolean> => {
    return new Promise((resolve) => {
      const timeout = setTimeout(() => {
        console.warn('[Export] Video seek timeout at time:', time);
        resolve(false);
      }, 1000);
      
      const onSeeked = () => {
        clearTimeout(timeout);
        video.removeEventListener('seeked', onSeeked);
        resolve(true);
      };
      
      video.addEventListener('seeked', onSeeked);
      
      const clampedTime = Math.max(0, Math.min(time, video.duration));
      
      // Only seek if significantly different
      if (Math.abs(video.currentTime - clampedTime) > 0.05) {
        video.currentTime = clampedTime;
      } else {
        clearTimeout(timeout);
        video.removeEventListener('seeked', onSeeked);
        resolve(true);
      }
    });
  };

  const renderFrameToCanvas = async (
    ctx: CanvasRenderingContext2D,
    time: number,
    canvasWidth: number,
    canvasHeight: number
  ): Promise<boolean> => {
    // Clear canvas with black
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);

    // Collect active clips (render from bottom track to top for proper layering)
    const activeClips: { clip: typeof editor.state.project.tracks[0]['clips'][0]; track: typeof editor.state.project.tracks[0]; zIndex: number }[] = [];
    let zIndex = 0;
    
    for (const track of editor.state.project.tracks) {
      if (track.muted || !track.visible) continue;
      
      for (const clip of track.clips) {
        const clipStart = clip.trackStart;
        const clipEnd = clip.trackStart + (clip.endTime - clip.startTime);
        
        if (time >= clipStart && time < clipEnd) {
          activeClips.push({ clip, track, zIndex: zIndex++ });
        }
      }
    }

    // Render each active clip
    for (const { clip, track } of activeClips) {
      const preloaded = preloadedMediaRef.current.get(clip.mediaId);
      
      if (!preloaded || !preloaded.ready) {
        console.warn('[Export] Media not ready:', clip.mediaId);
        continue;
      }
      
      if (preloaded.type === 'video') {
        const video = preloaded.element as HTMLVideoElement;
        const clipLocalTime = clip.startTime + (time - clip.trackStart);
        
        // Seek video to correct time
        const seeked = await seekVideo(video, clipLocalTime);
        if (!seeked) {
          console.warn('[Export] Failed to seek video for clip:', clip.name);
        }
        
        drawMediaToCanvas(ctx, video, canvasWidth, canvasHeight, clip.opacity);
      } else if (preloaded.type === 'image') {
        const img = preloaded.element as HTMLImageElement;
        drawMediaToCanvas(ctx, img, canvasWidth, canvasHeight, clip.opacity);
      }
    }

    // Render text overlays
    for (const overlay of editor.state.project.textOverlays) {
      if (time < overlay.startTime || time > overlay.endTime) continue;
      
      const scale = canvasWidth / 1920;
      const fontSize = overlay.fontSize * scale;
      
      ctx.font = `${overlay.fontWeight || '500'} ${fontSize}px ${overlay.fontFamily}`;
      ctx.fillStyle = overlay.color;
      ctx.textAlign = overlay.textAlign || 'center';
      ctx.textBaseline = 'middle';
      
      const x = (overlay.x / 100) * canvasWidth;
      const y = (overlay.y / 100) * canvasHeight;
      
      if (overlay.backgroundColor) {
        const metrics = ctx.measureText(overlay.text);
        const padding = 8 * scale;
        const bgWidth = metrics.width + padding * 2;
        const bgHeight = fontSize + padding * 2;
        
        ctx.fillStyle = overlay.backgroundColor;
        ctx.fillRect(x - bgWidth / 2, y - bgHeight / 2, bgWidth, bgHeight);
        ctx.fillStyle = overlay.color;
      }
      
      ctx.fillText(overlay.text, x, y);
    }
    
    return activeClips.length > 0 || editor.state.project.textOverlays.some(o => time >= o.startTime && time <= o.endTime);
  };

  // Get supported MIME type
  const getSupportedMimeType = (): string => {
    const types = [
      'video/webm;codecs=vp9',
      'video/webm;codecs=vp8',
      'video/webm;codecs=h264',
      'video/webm',
      'video/mp4;codecs=h264',
      'video/mp4',
    ];
    
    for (const type of types) {
      if (MediaRecorder.isTypeSupported(type)) {
        console.log('[Export] Using codec:', type);
        return type;
      }
    }
    
    console.warn('[Export] No specific codec supported, using default');
    return 'video/webm';
  };

  const startExport = async () => {
    const canvas = canvasRef.current;
    if (!canvas) {
      setErrorMessage('Canvas element not found');
      setExportPhase('error');
      return;
    }

    // Check MediaRecorder support
    if (typeof MediaRecorder === 'undefined') {
      setErrorMessage('Your browser does not support video recording. Please use a modern browser like Chrome or Firefox.');
      setExportPhase('error');
      return;
    }

    abortRef.current = false;
    chunksRef.current = [];
    preloadedMediaRef.current.clear();

    // Clean up any previous download URL
    if (downloadUrl) {
      URL.revokeObjectURL(downloadUrl);
      setDownloadUrl(null);
    }

    const resolution = RESOLUTION_PRESETS[settings.resolution];
    canvas.width = resolution.width;
    canvas.height = resolution.height;
    
    const ctx = canvas.getContext('2d', { alpha: false, willReadFrequently: false });
    if (!ctx) {
      setErrorMessage('Could not get canvas context');
      setExportPhase('error');
      return;
    }

    // Calculate total frames
    const fps = settings.fps;
    const duration = editor.state.project.duration;
    const frames = Math.ceil(duration * fps);
    setTotalFrames(frames);

    // Check if there's anything to export
    const hasContent = editor.state.project.tracks.some(t => t.clips.length > 0) || 
                       editor.state.project.textOverlays.length > 0;
    
    if (!hasContent) {
      setErrorMessage('Nothing to export. Add some media or text to your timeline.');
      setExportPhase('error');
      return;
    }

    // Phase 1: Preparing
    setExportPhase('preparing');
    editor.setIsExporting(true);
    setCurrentRenderTime('Loading media...');

    // Preload media
    const preloaded = await preloadMedia();
    if (!preloaded || abortRef.current) {
      setExportPhase('settings');
      editor.setIsExporting(false);
      return;
    }

    // Check if any media loaded
    if (preloadedMediaRef.current.size === 0 && editor.state.project.tracks.some(t => t.clips.length > 0)) {
      setErrorMessage('Failed to load any media files. Please check your media files and try again.');
      setExportPhase('error');
      editor.setIsExporting(false);
      return;
    }

    // Phase 2: Rendering
    setExportPhase('rendering');
    setRenderedFrames(0);
    setCurrentRenderTime(`Frame 0 / ${frames}`);

    // Setup MediaRecorder with proper codec detection
    const stream = canvas.captureStream(fps);
    const mimeType = getSupportedMimeType();
    
    const recorderOptions: MediaRecorderOptions = {
      videoBitsPerSecond: QUALITY_BITRATES[settings.quality],
      mimeType,
    };

    let mediaRecorder: MediaRecorder;
    
    try {
      mediaRecorder = new MediaRecorder(stream, recorderOptions);
    } catch (e) {
      console.error('[Export] MediaRecorder creation failed:', e);
      // Try without specifying mimeType
      try {
        mediaRecorder = new MediaRecorder(stream, { videoBitsPerSecond: QUALITY_BITRATES[settings.quality] });
      } catch (e2) {
        setErrorMessage('Failed to create video recorder. Your browser may not support this feature.');
        setExportPhase('error');
        editor.setIsExporting(false);
        return;
      }
    }

    mediaRecorderRef.current = mediaRecorder;

    mediaRecorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        chunksRef.current.push(e.data);
        console.log('[Export] Data chunk received:', e.data.size, 'bytes');
      }
    };

    mediaRecorder.onstop = () => {
      console.log('[Export] Recording stopped. Chunks:', chunksRef.current.length);
      
      if (abortRef.current) {
        setExportPhase('settings');
        editor.setIsExporting(false);
        return;
      }
      
      if (chunksRef.current.length === 0) {
        setErrorMessage('No video data was recorded. The timeline might be empty or media failed to load.');
        setExportPhase('error');
        editor.setIsExporting(false);
        return;
      }

      const totalSize = chunksRef.current.reduce((acc, chunk) => acc + chunk.size, 0);
      console.log('[Export] Total data size:', totalSize, 'bytes');
      
      if (totalSize < 1000) {
        setErrorMessage('Video file is too small. The export may have failed.');
        setExportPhase('error');
        editor.setIsExporting(false);
        return;
      }

      const blob = new Blob(chunksRef.current, { 
        type: mimeType.startsWith('video/mp4') ? 'video/mp4' : 'video/webm' 
      });
      
      const url = URL.createObjectURL(blob);
      const actualFormat = mimeType.startsWith('video/mp4') ? 'mp4' : 'webm';
      const filename = `${editor.state.project.name.replace(/[^a-z0-9]/gi, '_')}_${settings.resolution}.${actualFormat}`;
      
      console.log('[Export] Export complete:', filename, 'size:', formatFileSize(blob.size));
      
      setDownloadUrl(url);
      setDownloadFilename(filename);
      setFileSize(blob.size);
      
      setExportPhase('complete');
      editor.setIsExporting(false);
      editor.setExportProgress(100);
    };

    mediaRecorder.onerror = (event: Event) => {
      console.error('[Export] MediaRecorder error:', event);
      const errorEvent = event as ErrorEvent;
      setErrorMessage(`Recording error: ${errorEvent.message || 'Unknown error'}`);
      setExportPhase('error');
      editor.setIsExporting(false);
    };

    // Start recording with timeslice for better data collection
    mediaRecorder.start(500);

    // Render frames sequentially
    let framesRendered = 0;
    const frameInterval = 1 / fps;
    
    for (let frame = 0; frame < frames; frame++) {
      if (abortRef.current) {
        console.log('[Export] Export aborted at frame:', frame);
        break;
      }
      
      const time = frame * frameInterval;
      
      framesRendered = frame;
      setRenderedFrames(frame);
      editor.setExportProgress((frame / frames) * 100);
      setCurrentRenderTime(`${formatTime(time)} / ${formatTime(duration)}`);
      
      // Update preview time
      editor.setCurrentTime(time);
      
      // Render frame to canvas
      await renderFrameToCanvas(ctx, time, resolution.width, resolution.height);
      
      // Yield to allow UI updates and prevent browser freezing
      if (frame % 10 === 0) {
        await new Promise(resolve => setTimeout(resolve, 0));
      }
    }

    // Finalize
    if (mediaRecorder.state === 'recording') {
      // Request final data
      mediaRecorder.requestData();
      
      // Small delay to ensure data is collected
      await new Promise(resolve => setTimeout(resolve, 100));
      
      mediaRecorder.stop();
    }
    
    console.log('[Export] Rendering complete. Frames rendered:', framesRendered);
  };

  const handleManualDownload = (e: React.MouseEvent) => {
    if (!downloadUrl) {
      e.preventDefault();
      return;
    }
    
    // Create a proper download link
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = downloadFilename;
    link.style.display = 'none';
    
    document.body.appendChild(link);
    link.click();
    
    // Clean up after a delay
    setTimeout(() => {
      if (link.parentNode) {
        link.parentNode.removeChild(link);
      }
    }, 1000);
  };

  const handleCancel = () => {
    abortRef.current = true;
    
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
    
    setExportPhase('settings');
    setRenderedFrames(0);
    editor.setIsExporting(false);
    editor.setExportProgress(0);
  };

  const handleClose = () => {
    if (editor.state.isExporting) {
      handleCancel();
    }
    
    // Clean up download URL
    if (downloadUrl) {
      URL.revokeObjectURL(downloadUrl);
      setDownloadUrl(null);
    }
    
    editor.toggleExportPanel(false);
  };

  const handleRetry = () => {
    setExportPhase('settings');
    setErrorMessage('');
    setRenderedFrames(0);
    
    if (downloadUrl) {
      URL.revokeObjectURL(downloadUrl);
      setDownloadUrl(null);
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      abortRef.current = true;
      preloadedMediaRef.current.clear();
      
      if (downloadUrl) {
        URL.revokeObjectURL(downloadUrl);
      }
      
      if (downloadLinkRef.current && downloadLinkRef.current.parentNode) {
        downloadLinkRef.current.parentNode.removeChild(downloadLinkRef.current);
      }
    };
  }, [downloadUrl]);

  if (!editor.state.showExportPanel) return null;

  const hasContent = editor.state.project.tracks.some(t => t.clips.length > 0) || 
                     editor.state.project.textOverlays.length > 0;

  return (
    <div className="export-panel-overlay" onClick={handleClose}>
      <div className="export-panel" onClick={(e) => e.stopPropagation()}>
        <button className="export-close-btn" onClick={handleClose}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>

        <div className="export-panel-header">
          <div className="export-icon">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
              <polyline points="17 8 12 3 7 8" />
              <line x1="12" y1="3" x2="12" y2="15" />
            </svg>
          </div>
          <h2>Export Video</h2>
          <p>Render your project at the desired resolution and quality</p>
        </div>

        {exportPhase === 'settings' && (
          <div className="export-settings">
            {!hasContent && (
              <div className="export-warning">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" />
                  <line x1="12" y1="8" x2="12" y2="12" />
                  <line x1="12" y1="16" x2="12.01" y2="16" />
                </svg>
                <span>Add media or text to your timeline before exporting</span>
              </div>
            )}

            <div className="setting-group">
              <label>Resolution</label>
              <div className="resolution-grid">
                {(Object.keys(RESOLUTION_PRESETS) as Array<keyof typeof RESOLUTION_PRESETS>).map((res) => (
                  <button
                    key={res}
                    className={`resolution-btn ${settings.resolution === res ? 'selected' : ''}`}
                    onClick={() => handleSettingChange('resolution', res)}
                  >
                    <span className="res-label">{res}</span>
                    <span className="res-dimensions">
                      {RESOLUTION_PRESETS[res].width}×{RESOLUTION_PRESETS[res].height}
                    </span>
                    {res === '4K' && <span className="res-badge">Best Quality</span>}
                    {res === '720p' && <span className="res-badge small">Fast</span>}
                  </button>
                ))}
              </div>
            </div>

            <div className="setting-row">
              <div className="setting-group">
                <label>Frame Rate</label>
                <div className="fps-buttons">
                  {[24, 30, 60].map((fps) => (
                    <button
                      key={fps}
                      className={`fps-btn ${settings.fps === fps ? 'selected' : ''}`}
                      onClick={() => handleSettingChange('fps', fps as 24 | 30 | 60)}
                    >
                      {fps} FPS
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="setting-row">
              <div className="setting-group">
                <label>Quality</label>
                <div className="quality-buttons">
                  {(['low', 'medium', 'high', 'ultra'] as const).map((quality) => (
                    <button
                      key={quality}
                      className={`quality-btn ${settings.quality === quality ? 'selected' : ''}`}
                      onClick={() => handleSettingChange('quality', quality)}
                    >
                      {quality.charAt(0).toUpperCase() + quality.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="export-info-card">
              <div className="info-row">
                <span className="info-label">Duration</span>
                <span className="info-value">
                  {Math.floor(editor.state.project.duration / 60)}:{Math.floor(editor.state.project.duration % 60).toString().padStart(2, '0')}
                </span>
              </div>
              <div className="info-row">
                <span className="info-label">Estimated Size</span>
                <span className="info-value">{estimateFileSize()}</span>
              </div>
              <div className="info-row">
                <span className="info-label">Output Resolution</span>
                <span className="info-value">
                  {RESOLUTION_PRESETS[settings.resolution].width} × {RESOLUTION_PRESETS[settings.resolution].height}
                </span>
              </div>
              <div className="info-row">
                <span className="info-label">Total Frames</span>
                <span className="info-value">
                  {Math.ceil(editor.state.project.duration * settings.fps)}
                </span>
              </div>
            </div>

            <div className="export-note">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="16" x2="12" y2="12" />
                <line x1="12" y1="8" x2="12.01" y2="8" />
              </svg>
              <span>Export uses WebM format for best browser compatibility. The video will download automatically when complete.</span>
            </div>

            <button 
              className="export-start-btn" 
              onClick={startExport}
              disabled={!hasContent}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polygon points="5 3 19 12 5 21 5 3" />
              </svg>
              Start Export
            </button>
          </div>
        )}

        {exportPhase === 'preparing' && (
          <div className="export-progress">
            <div className="preparing-animation">
              <div className="spinner"></div>
            </div>
            <h3>Preparing Export</h3>
            <p className="progress-details">{currentRenderTime}</p>
            <button className="export-cancel-btn" onClick={handleCancel}>
              Cancel
            </button>
          </div>
        )}

        {exportPhase === 'rendering' && (
          <div className="export-progress">
            <div className="progress-animation">
              <div className="progress-ring">
                <svg width="120" height="120">
                  <circle
                    className="progress-ring-bg"
                    cx="60"
                    cy="60"
                    r="54"
                    fill="none"
                    stroke="var(--bg-tertiary)"
                    strokeWidth="8"
                  />
                  <circle
                    className="progress-ring-fill"
                    cx="60"
                    cy="60"
                    r="54"
                    fill="none"
                    stroke="url(#progressGradient)"
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={`${(editor.state.exportProgress / 100) * 339.3} 339.3`}
                    transform="rotate(-90 60 60)"
                  />
                  <defs>
                    <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#6366f1" />
                      <stop offset="100%" stopColor="#8b5cf6" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="progress-percent">
                  {Math.round(editor.state.exportProgress)}%
                </div>
              </div>
            </div>

            <h3>Rendering Video</h3>
            <p className="progress-details">
              {currentRenderTime}
            </p>
            
            <div className="progress-bar-container">
              <div 
                className="progress-bar-fill"
                style={{ width: `${editor.state.exportProgress}%` }}
              />
            </div>

            <p className="progress-tip">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="16" x2="12" y2="12" />
                <line x1="12" y1="8" x2="12.01" y2="8" />
              </svg>
              Please don't close this window during export
            </p>
            
            <button className="export-cancel-btn" onClick={handleCancel}>
              Cancel Export
            </button>
          </div>
        )}

        {exportPhase === 'error' && (
          <div className="export-error">
            <div className="error-icon">
              <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <line x1="15" y1="9" x2="9" y2="15" />
                <line x1="9" y1="9" x2="15" y2="15" />
              </svg>
            </div>
            <h3>Export Failed</h3>
            <p>{errorMessage || 'An error occurred during export. Please try again.'}</p>
            
            <div className="error-actions">
              <button className="export-retry-btn" onClick={handleRetry}>
                Try Again
              </button>
              <button className="export-cancel-btn" onClick={handleClose}>
                Close
              </button>
            </div>
          </div>
        )}

        {exportPhase === 'complete' && (
          <div className="export-complete">
            <div className="complete-icon">
              <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M22 11.08V12a10 10 0 11-5.93-9.14" />
                <polyline points="22 4 12 14.01 9 11.01" />
              </svg>
            </div>
            <h3>Export Complete!</h3>
            <p>Your video is ready for download</p>
            
            <div className="export-summary">
              <div className="summary-item">
                <span className="summary-label">File Name</span>
                <span className="summary-value filename">{downloadFilename}</span>
              </div>
              <div className="summary-item">
                <span className="summary-label">File Size</span>
                <span className="summary-value">{formatFileSize(fileSize)}</span>
              </div>
              <div className="summary-item">
                <span className="summary-label">Resolution</span>
                <span className="summary-value">{settings.resolution} ({RESOLUTION_PRESETS[settings.resolution].width}×{RESOLUTION_PRESETS[settings.resolution].height})</span>
              </div>
              <div className="summary-item">
                <span className="summary-label">Frame Rate</span>
                <span className="summary-value">{settings.fps} FPS</span>
              </div>
            </div>

            <div className="download-actions">
              <button 
                className="download-btn primary" 
                onClick={handleManualDownload}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
                  <polyline points="7 10 12 15 17 10" />
                  <line x1="12" y1="15" x2="12" y2="3" />
                </svg>
                Download Video
              </button>
              
              {downloadUrl && (
                <a 
                  href={downloadUrl} 
                  download={downloadFilename}
                  className="download-btn secondary"
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="10" />
                    <polygon points="10 8 16 12 10 16 10 8" />
                  </svg>
                  Preview in Browser
                </a>
              )}
            </div>

            <button className="export-done-btn" onClick={handleClose}>
              Done
            </button>
          </div>
        )}

        <canvas ref={canvasRef} style={{ display: 'none' }} />
      </div>
    </div>
  );
};

export default ExportPanel;
