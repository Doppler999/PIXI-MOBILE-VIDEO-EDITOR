
import React, { useState } from 'react';
import { useEditorStore } from '../../stores/editorStore';
import { Clip as ClipType } from '../../types/editor';
import './Clip.css';

interface ClipProps {
  clip: ClipType;
  editor: ReturnType<typeof useEditorStore>;
  pixelsPerSecond: number;
}

const Clip: React.FC<ClipProps> = ({ clip, editor, pixelsPerSecond }) => {
  const [isResizing, setIsResizing] = useState<'left' | 'right' | null>(null);
  const isSelected = editor.state.selectedClipId === clip.id;

  const clipDuration = clip.endTime - clip.startTime;
  const width = clipDuration * pixelsPerSecond;
  const left = clip.trackStart * pixelsPerSecond;

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    editor.selectClip(clip.id);
  };

  const handleDoubleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Split clip at current playhead
    editor.splitClip(clip.id, editor.state.currentTime);
  };

  const handleDragStart = (e: React.MouseEvent) => {
    e.preventDefault();
    const startX = e.clientX;
    const originalTrackStart = clip.trackStart;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const deltaX = moveEvent.clientX - startX;
      const deltaTime = deltaX / pixelsPerSecond;
      const newTrackStart = Math.max(0, originalTrackStart + deltaTime);
      
      editor.updateClip(clip.id, { trackStart: newTrackStart });
    };

    const handleMouseUp = () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  const handleResizeStart = (e: React.MouseEvent, direction: 'left' | 'right') => {
    e.stopPropagation();
    e.preventDefault();
    setIsResizing(direction);

    const startX = e.clientX;
    const originalTrimStart = clip.trimStart;
    const originalTrimEnd = clip.trimEnd;
    const originalTrackStart = clip.trackStart;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const deltaX = moveEvent.clientX - startX;
      const deltaTime = deltaX / pixelsPerSecond;

      if (direction === 'left') {
        const newTrimStart = Math.max(0, originalTrimStart + deltaTime);
        const newTrackStart = originalTrackStart + deltaTime;
        if (newTrackStart >= 0) {
          editor.updateClip(clip.id, { 
            trimStart: newTrimStart,
            trackStart: newTrackStart,
            startTime: clip.startTime + deltaTime,
          });
        }
      } else {
        const newTrimEnd = Math.max(0, originalTrimEnd - deltaTime);
        editor.updateClip(clip.id, { 
          trimEnd: newTrimEnd,
          endTime: clip.endTime - deltaTime,
        });
      }
    };

    const handleMouseUp = () => {
      setIsResizing(null);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  const handleDelete = () => {
    editor.deleteClip(clip.id);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const trackType = editor.state.project.tracks.find(t => t.id === clip.trackId)?.type || 'video';

  return (
    <div
      className={`clip ${trackType} ${isSelected ? 'selected' : ''}`}
      style={{ 
        width: Math.max(width, 20), 
        left,
      }}
      onClick={handleClick}
      onDoubleClick={handleDoubleClick}
      onMouseDown={handleDragStart}
    >
      <div 
        className="clip-resize-handle left"
        onMouseDown={(e) => handleResizeStart(e, 'left')}
      />
      <div className="clip-content">
        <div className="clip-thumbnail">
          {clip.thumbnail ? (
            <img src={clip.thumbnail} alt={clip.name} />
          ) : (
            <div className="clip-thumbnail-placeholder">
              {clip.type === 'video' && (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                  <polygon points="5 3 19 12 5 21 5 3" />
                </svg>
              )}
              {clip.type === 'audio' && (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M9 18V5l12-2v13" />
                  <circle cx="6" cy="18" r="3" />
                  <circle cx="18" cy="16" r="3" />
                </svg>
              )}
              {clip.type === 'image' && (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
                  <circle cx="8.5" cy="8.5" r="1.5" />
                  <polyline points="21 15 16 10 5 21" />
                </svg>
              )}
            </div>
          )}
        </div>
        <div className="clip-info">
          <span className="clip-name">{clip.name}</span>
          <span className="clip-duration">{formatDuration(clipDuration)}</span>
        </div>
        {isSelected && (
          <button className="clip-delete" onClick={handleDelete}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        )}
      </div>
      <div 
        className="clip-resize-handle right"
        onMouseDown={(e) => handleResizeStart(e, 'right')}
      />
      {clip.type === 'audio' && (
        <div className="waveform">
          {Array.from({ length: Math.floor(width / 4) }).map((_, i) => (
            <div 
              key={i} 
              className="waveform-bar"
              style={{ 
                height: `${20 + Math.random() * 60}%`,
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default Clip;
