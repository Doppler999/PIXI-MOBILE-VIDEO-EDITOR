
import React, { useRef, useEffect, useState } from 'react';
import { useEditorStore } from '../../stores/editorStore';
import Track from './Track';
import './Timeline.css';

interface TimelineProps {
  editor: ReturnType<typeof useEditorStore>;
}

const Timeline: React.FC<TimelineProps> = ({ editor }) => {
  const timelineRef = useRef<HTMLDivElement>(null);
  const [isDraggingPlayhead, setIsDraggingPlayhead] = useState(false);

  const pixelsPerSecond = 80 * editor.state.zoom;
  const timelineWidth = Math.max(editor.state.project.duration * pixelsPerSecond, 1000);

  const handleTimelineClick = (e: React.MouseEvent) => {
    if (!timelineRef.current) return;
    const rect = timelineRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left + timelineRef.current.scrollLeft;
    const time = x / pixelsPerSecond;
    editor.setCurrentTime(Math.max(0, Math.min(time, editor.state.project.duration)));
  };

  const handlePlayheadDrag = (e: React.MouseEvent) => {
    if (!isDraggingPlayhead || !timelineRef.current) return;
    const rect = timelineRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left + timelineRef.current.scrollLeft;
    const time = x / pixelsPerSecond;
    editor.setCurrentTime(Math.max(0, Math.min(time, editor.state.project.duration)));
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => handlePlayheadDrag(e as any);
    const handleMouseUp = () => setIsDraggingPlayhead(false);

    if (isDraggingPlayhead) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDraggingPlayhead]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const timeMarkers = [];
  const interval = editor.state.zoom >= 1 ? 1 : editor.state.zoom >= 0.5 ? 2 : 5;
  for (let i = 0; i <= editor.state.project.duration; i += interval) {
    timeMarkers.push(i);
  }

  return (
    <div className="timeline">
      <div className="timeline-toolbar">
        <div className="zoom-controls">
          <button 
            className="zoom-btn"
            onClick={() => editor.setZoom(editor.state.zoom - 0.1)}
            disabled={editor.state.zoom <= 0.1}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="5" y1="12" x2="19" y2="12" />
            </svg>
          </button>
          <span className="zoom-value">{Math.round(editor.state.zoom * 100)}%</span>
          <button 
            className="zoom-btn"
            onClick={() => editor.setZoom(editor.state.zoom + 0.1)}
            disabled={editor.state.zoom >= 5}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="12" y1="5" x2="12" y2="19" />
              <line x1="5" y1="12" x2="19" y2="12" />
            </svg>
          </button>
        </div>
        <div className="timeline-actions">
          <button 
            className={`action-btn ${editor.state.snapEnabled ? 'active' : ''}`}
            onClick={() => editor.updateState({ snapEnabled: !editor.state.snapEnabled })}
            title="Snap to grid"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="7" height="7" />
              <rect x="14" y="3" width="7" height="7" />
              <rect x="3" y="14" width="7" height="7" />
              <rect x="14" y="14" width="7" height="7" />
            </svg>
          </button>
        </div>
      </div>

      <div className="timeline-content">
        <div className="track-labels">
          <div className="time-ruler-label">
            <span>Time</span>
          </div>
          {editor.state.project.tracks.map(track => (
            <div 
              key={track.id} 
              className="track-label"
              style={{ height: track.height }}
            >
              <span className={`track-type-indicator ${track.type}`} />
              <span className="track-name">{track.name}</span>
              <div className="track-controls">
                <button 
                  className={`track-control-btn ${track.muted ? 'active' : ''}`}
                  onClick={() => editor.toggleTrackMute(track.id)}
                  title={track.muted ? 'Unmute' : 'Mute'}
                >
                  {track.muted ? (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                      <line x1="23" y1="9" x2="17" y2="15" />
                      <line x1="17" y1="9" x2="23" y2="15" />
                    </svg>
                  ) : (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                      <path d="M19.07 4.93a10 10 0 010 14.14M15.54 8.46a5 5 0 010 7.07" />
                    </svg>
                  )}
                </button>
                <button 
                  className={`track-control-btn ${track.locked ? 'active' : ''}`}
                  onClick={() => editor.toggleTrackLock(track.id)}
                  title={track.locked ? 'Unlock' : 'Lock'}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    {track.locked ? (
                      <>
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                        <path d="M7 11V7a5 5 0 0110 0v4" />
                      </>
                    ) : (
                      <>
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                        <path d="M7 11V7a5 5 0 019.9-1" />
                      </>
                    )}
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="timeline-scroll" ref={timelineRef}>
          <div 
            className="timeline-tracks"
            style={{ width: timelineWidth }}
            onClick={handleTimelineClick}
          >
            {/* Time ruler */}
            <div className="time-ruler">
              {timeMarkers.map(time => (
                <div 
                  key={time} 
                  className="time-marker"
                  style={{ left: time * pixelsPerSecond }}
                >
                  <span>{formatTime(time)}</span>
                  <div className="marker-line" />
                </div>
              ))}
            </div>

            {/* Tracks */}
            {editor.state.project.tracks.map(track => (
              <Track 
                key={track.id} 
                track={track} 
                editor={editor}
                pixelsPerSecond={pixelsPerSecond}
              />
            ))}

            {/* Playhead */}
            <div 
              className="playhead"
              style={{ left: editor.state.currentTime * pixelsPerSecond }}
              onMouseDown={() => setIsDraggingPlayhead(true)}
            >
              <div className="playhead-handle">
                <svg width="12" height="8" viewBox="0 0 12 8">
                  <polygon points="6,8 0,0 12,0" fill="currentColor" />
                </svg>
              </div>
              <div className="playhead-line" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Timeline;
