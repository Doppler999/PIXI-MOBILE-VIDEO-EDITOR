
import React from 'react';
import { useEditorStore } from '../../stores/editorStore';
import { Track as TrackType } from '../../types/editor';
import Clip from './Clip';
import './Track.css';

interface TrackProps {
  track: TrackType;
  editor: ReturnType<typeof useEditorStore>;
  pixelsPerSecond: number;
}

const Track: React.FC<TrackProps> = ({ track, editor, pixelsPerSecond }) => {
  return (
    <div 
      className={`track ${track.locked ? 'locked' : ''} ${track.muted ? 'muted' : ''}`}
      style={{ height: track.height }}
    >
      {track.clips.map(clip => (
        <Clip 
          key={clip.id} 
          clip={clip} 
          editor={editor}
          pixelsPerSecond={pixelsPerSecond}
        />
      ))}
      {track.clips.length === 0 && (
        <div className="track-empty">
          <span>Drop media here</span>
        </div>
      )}
    </div>
  );
};

export default Track;
