
export interface MediaItem {
  id: string;
  name: string;
  type: 'video' | 'audio' | 'image';
  duration: number;
  thumbnail?: string;
  file?: File;
  url?: string;
}

export interface Clip {
  id: string;
  mediaId: string;
  trackId: string;
  startTime: number;
  endTime: number;
  trackStart: number;
  trimStart: number;
  trimEnd: number;
  name: string;
  thumbnail?: string;
  type: 'video' | 'audio' | 'image';
  effects: Effect[];
  opacity: number;
  volume: number;
  muted: boolean;
}

export interface Track {
  id: string;
  type: 'video' | 'audio' | 'text';
  name: string;
  clips: Clip[];
  muted: boolean;
  locked: boolean;
  visible: boolean;
  height: number;
}

export interface Effect {
  id: string;
  type: 'filter' | 'transition' | 'text' | 'sticker';
  name: string;
  params: Record<string, any>;
}

export interface TextOverlay {
  id: string;
  text: string;
  x: number;
  y: number;
  fontSize: number;
  fontFamily: string;
  color: string;
  backgroundColor?: string;
  startTime: number;
  endTime: number;
  trackId: string;
  animation?: 'none' | 'fadeIn' | 'slideUp' | 'typewriter' | 'bounce';
  fontWeight?: string;
  textAlign?: 'left' | 'center' | 'right';
}

export interface Project {
  id: string;
  name: string;
  tracks: Track[];
  textOverlays: TextOverlay[];
  duration: number;
  createdAt: Date;
  updatedAt: Date;
  width: number;
  height: number;
  fps: number;
}

export interface EditorState {
  project: Project;
  currentTime: number;
  isPlaying: boolean;
  zoom: number;
  selectedClipId: string | null;
  selectedTrackId: string | null;
  selectedTextId: string | null;
  mediaLibrary: MediaItem[];
  isDragging: boolean;
  dragClip: Clip | null;
  snapEnabled: boolean;
  showEffects: boolean;
  showText: boolean;
  showMedia: boolean;
  showExportPanel: boolean;
  exportProgress: number;
  isExporting: boolean;
}

export interface ExportSettings {
  resolution: '720p' | '1080p' | '2K' | '4K';
  fps: 24 | 30 | 60;
  format: 'webm' | 'mp4';
  quality: 'low' | 'medium' | 'high' | 'ultra';
}

export const RESOLUTION_PRESETS = {
  '720p': { width: 1280, height: 720, label: '720p HD' },
  '1080p': { width: 1920, height: 1080, label: '1080p Full HD' },
  '2K': { width: 2560, height: 1440, label: '2K QHD' },
  '4K': { width: 3840, height: 2160, label: '4K UHD' },
};

export const QUALITY_BITRATES = {
  low: 2000000,
  medium: 5000000,
  high: 10000000,
  ultra: 20000000,
};
