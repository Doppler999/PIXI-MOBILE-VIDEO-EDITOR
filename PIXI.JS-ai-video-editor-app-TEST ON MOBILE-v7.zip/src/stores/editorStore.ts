
import { useState, useCallback } from 'react';
import { EditorState, Track, Clip, MediaItem, TextOverlay, Project } from '../types/editor';

const generateId = () => Math.random().toString(36).substr(2, 9);

const createDefaultProject = (): Project => ({
  id: generateId(),
  name: 'Untitled Project',
  tracks: [
    { id: 'track-1', type: 'video', name: 'Video 1', clips: [], muted: false, locked: false, visible: true, height: 60 },
    { id: 'track-2', type: 'video', name: 'Video 2', clips: [], muted: false, locked: false, visible: true, height: 60 },
    { id: 'track-3', type: 'audio', name: 'Audio 1', clips: [], muted: false, locked: false, visible: true, height: 50 },
    { id: 'track-4', type: 'audio', name: 'Audio 2', clips: [], muted: false, locked: false, visible: true, height: 50 },
    { id: 'track-5', type: 'text', name: 'Text', clips: [], muted: false, locked: false, visible: true, height: 40 },
  ],
  textOverlays: [],
  duration: 60,
  createdAt: new Date(),
  updatedAt: new Date(),
  width: 1920,
  height: 1080,
  fps: 30,
});

const initialState: EditorState = {
  project: createDefaultProject(),
  currentTime: 0,
  isPlaying: false,
  zoom: 1,
  selectedClipId: null,
  selectedTrackId: null,
  selectedTextId: null,
  mediaLibrary: [],
  isDragging: false,
  dragClip: null,
  snapEnabled: true,
  showEffects: false,
  showText: false,
  showMedia: true,
  showExportPanel: false,
  exportProgress: 0,
  isExporting: false,
};

export function useEditorStore() {
  const [state, setState] = useState<EditorState>(initialState);

  const updateState = useCallback((updates: Partial<EditorState>) => {
    setState(prev => ({ ...prev, ...updates }));
  }, []);

  const setCurrentTime = useCallback((time: number) => {
    setState(prev => ({
      ...prev,
      currentTime: Math.max(0, Math.min(time, prev.project.duration)),
    }));
  }, []);

  const setIsPlaying = useCallback((playing: boolean) => {
    setState(prev => ({ ...prev, isPlaying: playing }));
  }, []);

  const setZoom = useCallback((zoom: number) => {
    setState(prev => ({ ...prev, zoom: Math.max(0.1, Math.min(zoom, 5)) }));
  }, []);

  const selectClip = useCallback((clipId: string | null) => {
    setState(prev => ({ 
      ...prev, 
      selectedClipId: clipId,
      selectedTextId: null,
    }));
  }, []);

  const selectTrack = useCallback((trackId: string | null) => {
    setState(prev => ({ ...prev, selectedTrackId: trackId }));
  }, []);

  const selectText = useCallback((textId: string | null) => {
    setState(prev => ({ 
      ...prev, 
      selectedTextId: textId,
      selectedClipId: null,
    }));
  }, []);

  const addMediaToLibrary = useCallback((media: MediaItem) => {
    setState(prev => ({
      ...prev,
      mediaLibrary: [...prev.mediaLibrary, media],
    }));
  }, []);

  const removeMediaFromLibrary = useCallback((mediaId: string) => {
    setState(prev => ({
      ...prev,
      mediaLibrary: prev.mediaLibrary.filter(m => m.id !== mediaId),
    }));
  }, []);

  const addClipToTrack = useCallback((trackId: string, clip: Omit<Clip, 'id' | 'trackId'>) => {
    setState(prev => {
      const newClip: Clip = {
        ...clip,
        id: generateId(),
        trackId,
      };
      
      const tracks = prev.project.tracks.map(track => {
        if (track.id === trackId) {
          return { ...track, clips: [...track.clips, newClip] };
        }
        return track;
      });

      const newDuration = Math.max(
        prev.project.duration,
        ...tracks.flatMap(t => t.clips.map(c => c.trackStart + (c.endTime - c.startTime)))
      );

      return {
        ...prev,
        project: {
          ...prev.project,
          tracks,
          duration: newDuration,
          updatedAt: new Date(),
        },
      };
    });
  }, []);

  const updateClip = useCallback((clipId: string, updates: Partial<Clip>) => {
    setState(prev => ({
      ...prev,
      project: {
        ...prev.project,
        tracks: prev.project.tracks.map(track => ({
          ...track,
          clips: track.clips.map(clip => 
            clip.id === clipId ? { ...clip, ...updates } : clip
          ),
        })),
        updatedAt: new Date(),
      },
    }));
  }, []);

  const deleteClip = useCallback((clipId: string) => {
    setState(prev => ({
      ...prev,
      project: {
        ...prev.project,
        tracks: prev.project.tracks.map(track => ({
          ...track,
          clips: track.clips.filter(clip => clip.id !== clipId),
        })),
        updatedAt: new Date(),
      },
      selectedClipId: prev.selectedClipId === clipId ? null : prev.selectedClipId,
    }));
  }, []);

  const splitClip = useCallback((clipId: string, splitTime: number) => {
    setState(prev => {
      const tracks = prev.project.tracks.map(track => {
        const clipIndex = track.clips.findIndex(c => c.id === clipId);
        if (clipIndex === -1) return track;

        const clip = track.clips[clipIndex];
        const clipDuration = clip.endTime - clip.startTime;
        const relativeTime = splitTime - clip.trackStart;

        if (relativeTime <= 0 || relativeTime >= clipDuration) return track;

        const firstClip: Clip = {
          ...clip,
          endTime: clip.startTime + relativeTime,
        };

        const secondClip: Clip = {
          ...clip,
          id: generateId(),
          startTime: clip.startTime + relativeTime,
          trackStart: splitTime,
        };

        const newClips = [...track.clips];
        newClips.splice(clipIndex, 1, firstClip, secondClip);
        return { ...track, clips: newClips };
      });

      return {
        ...prev,
        project: { ...prev.project, tracks, updatedAt: new Date() },
      };
    });
  }, []);

  const addTrack = useCallback((type: 'video' | 'audio' | 'text') => {
    setState(prev => {
      const existingCount = prev.project.tracks.filter(t => t.type === type).length;
      const newTrack: Track = {
        id: generateId(),
        type,
        name: `${type.charAt(0).toUpperCase() + type.slice(1)} ${existingCount + 1}`,
        clips: [],
        muted: false,
        locked: false,
        visible: true,
        height: type === 'text' ? 40 : type === 'audio' ? 50 : 60,
      };
      return {
        ...prev,
        project: {
          ...prev.project,
          tracks: [...prev.project.tracks, newTrack],
          updatedAt: new Date(),
        },
      };
    });
  }, []);

  const deleteTrack = useCallback((trackId: string) => {
    setState(prev => ({
      ...prev,
      project: {
        ...prev.project,
        tracks: prev.project.tracks.filter(t => t.id !== trackId),
        updatedAt: new Date(),
      },
    }));
  }, []);

  const toggleTrackMute = useCallback((trackId: string) => {
    setState(prev => ({
      ...prev,
      project: {
        ...prev.project,
        tracks: prev.project.tracks.map(t =>
          t.id === trackId ? { ...t, muted: !t.muted } : t
        ),
        updatedAt: new Date(),
      },
    }));
  }, []);

  const toggleTrackLock = useCallback((trackId: string) => {
    setState(prev => ({
      ...prev,
      project: {
        ...prev.project,
        tracks: prev.project.tracks.map(t =>
          t.id === trackId ? { ...t, locked: !t.locked } : t
        ),
        updatedAt: new Date(),
      },
    }));
  }, []);

  const addTextOverlay = useCallback((text: Omit<TextOverlay, 'id'>) => {
    setState(prev => ({
      ...prev,
      project: {
        ...prev.project,
        textOverlays: [...prev.project.textOverlays, { ...text, id: generateId() }],
        updatedAt: new Date(),
      },
    }));
  }, []);

  const updateTextOverlay = useCallback((textId: string, updates: Partial<TextOverlay>) => {
    setState(prev => ({
      ...prev,
      project: {
        ...prev.project,
        textOverlays: prev.project.textOverlays.map(t =>
          t.id === textId ? { ...t, ...updates } : t
        ),
        updatedAt: new Date(),
      },
    }));
  }, []);

  const deleteTextOverlay = useCallback((textId: string) => {
    setState(prev => ({
      ...prev,
      project: {
        ...prev.project,
        textOverlays: prev.project.textOverlays.filter(t => t.id !== textId),
        updatedAt: new Date(),
      },
      selectedTextId: prev.selectedTextId === textId ? null : prev.selectedTextId,
    }));
  }, []);

  const setDragState = useCallback((isDragging: boolean, dragClip: Clip | null) => {
    setState(prev => ({ ...prev, isDragging, dragClip }));
  }, []);

  const togglePanel = useCallback((panel: 'effects' | 'text' | 'media') => {
    setState(prev => ({
      ...prev,
      showEffects: panel === 'effects' ? !prev.showEffects : false,
      showText: panel === 'text' ? !prev.showText : false,
      showMedia: panel === 'media' ? !prev.showMedia : false,
    }));
  }, []);

  const toggleExportPanel = useCallback((show: boolean) => {
    setState(prev => ({ ...prev, showExportPanel: show }));
  }, []);

  const setExportProgress = useCallback((progress: number) => {
    setState(prev => ({ ...prev, exportProgress: progress }));
  }, []);

  const setIsExporting = useCallback((isExporting: boolean) => {
    setState(prev => ({ ...prev, isExporting }));
  }, []);

  return {
    state,
    updateState,
    setCurrentTime,
    setIsPlaying,
    setZoom,
    selectClip,
    selectTrack,
    selectText,
    addMediaToLibrary,
    removeMediaFromLibrary,
    addClipToTrack,
    updateClip,
    deleteClip,
    splitClip,
    addTrack,
    deleteTrack,
    toggleTrackMute,
    toggleTrackLock,
    addTextOverlay,
    updateTextOverlay,
    deleteTextOverlay,
    setDragState,
    togglePanel,
    toggleExportPanel,
    setExportProgress,
    setIsExporting,
  };
}
