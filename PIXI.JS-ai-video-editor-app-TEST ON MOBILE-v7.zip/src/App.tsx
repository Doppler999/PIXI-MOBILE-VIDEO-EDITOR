
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { useEditorStore } from './stores/editorStore';
import Header from './components/Header/Header';
import Preview from './components/Preview/Preview';
import Timeline from './components/Timeline/Timeline';
import MediaPanel from './components/MediaPanel/MediaPanel';
import EffectsPanel from './components/EffectsPanel/EffectsPanel';
import TextPanel from './components/TextPanel/TextPanel';
import Toolbar from './components/Toolbar/Toolbar';
import MobileControls from './components/MobileControls/MobileControls';
import ExportPanel from './components/ExportPanel/ExportPanel';
import './App.css';

function App() {
  const editor = useEditorStore();
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const playIntervalRef = useRef<number | null>(null);
  const lastFrameTimeRef = useRef<number>(0);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Playback logic with proper timing
  useEffect(() => {
    if (editor.state.isPlaying && !editor.state.isExporting) {
      const startTime = performance.now();
      const startOffset = editor.state.currentTime;
      
      const animate = (currentFrameTime: number) => {
        const elapsed = (currentFrameTime - startTime) / 1000;
        const newTime = startOffset + elapsed;
        
        if (newTime >= editor.state.project.duration) {
          editor.setCurrentTime(0);
          editor.setIsPlaying(false);
        } else {
          editor.setCurrentTime(newTime);
          playIntervalRef.current = requestAnimationFrame(animate);
        }
      };
      
      playIntervalRef.current = requestAnimationFrame(animate);
    } else {
      if (playIntervalRef.current) {
        cancelAnimationFrame(playIntervalRef.current);
        playIntervalRef.current = null;
      }
    }

    return () => {
      if (playIntervalRef.current) {
        cancelAnimationFrame(playIntervalRef.current);
      }
    };
  }, [editor.state.isPlaying, editor.state.project.duration, editor.state.isExporting]);

  return (
    <div className="app">
      <Header editor={editor} />
      <div className="main-content">
        <div className="left-panel">
          {editor.state.showMedia && <MediaPanel editor={editor} />}
          {editor.state.showEffects && <EffectsPanel editor={editor} />}
          {editor.state.showText && <TextPanel editor={editor} />}
        </div>
        <div className="center-panel">
          <Preview editor={editor} />
          {isMobile && <MobileControls editor={editor} />}
        </div>
      </div>
      <Toolbar editor={editor} />
      <Timeline editor={editor} />
      <ExportPanel editor={editor} />
    </div>
  );
}

export default App;
